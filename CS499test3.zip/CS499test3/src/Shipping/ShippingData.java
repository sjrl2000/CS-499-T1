
package Shipping;


public class ShippingData {
    
}
