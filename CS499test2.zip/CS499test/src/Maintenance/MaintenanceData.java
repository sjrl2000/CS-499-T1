package Maintenance;

import java.util.*;

public class MaintenanceData 
{
  
    String inspection_date = "null";
    String inspection_type = "null";
    String repair_desc = "null";
    String parts = "null";
    String stock_order = "null";
    String order_loc = "null";
    float cost = 0;
    

    MaintenanceData(string i_date, string i_type, string r_desc, string p, string so, string ol, string c)
    {
        inspection_date = i_date;
        inspection_type = i_type;
        repair_desc = r_desc;
        parts = p;
        stock_order = so;
        order_loc = ol;
        cost = c;

    }

   
   String getIDate()
   {
        return inspection_date;
   }

   void setIDate(string id)
   {
        inspection_date = id;
   }

 String getIType()
   {
        return inspection_type;
   }

   void setIDate(string type)
   {
        inspection_type = type;
   }

    String getRepairD()
   {
        return repair_desc;
   }

   void setRepairD(string desc)
   {
        repair_desc = desc;
   }

    String getPartsUsed()
   {
        return parts;
   }

   void setPartsUsed(string p)
   {
        parts = p;
   }

    String getStockOrder()
   {
        return so;
   }

   void setStockOrder(string st_or)
   {
        so = st_or;
   }

    String getOrderLocation()
   {
        return order_loc;
   }

   void setIDate(string or_loc)
   {
        ol = or_loc ;
   }

    float getCost()
   {
        return cost;
   }

   void setIDate(float c)
   {
        cost = c;
   }
    
}


