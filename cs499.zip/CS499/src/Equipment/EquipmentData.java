package Equipment;




import java.util.*;

public class EquipmentData {
    
    
    
    
    
    
    int vID = 0;
    String vBrand = "null";
    String vYear = "null";
    String vModel = "null";
    String vType = "null";
    List<String> vPartsList = new ArrayList<>();
    
    
}
