
package Personal;

public class ModelGUI {
    
    public void setUserNameGUI(String uNameGUI){
        this.userNameGUI = uNameGUI;
    }
    
    public String getUserNameGUI(){
        return this.userNameGUI;
    }
    
    public void setUserPasswordGUI(String uPasswordGUI){
        this.userPasswordGUI = uPasswordGUI;
    }
    
    public String getUserPasswordGUI(){
        return this.userPasswordGUI;
    }
    
    String userNameGUI = "";
    String userPasswordGUI = "";
    
}
